<?php
/**
 * Beneficiary self-registration has been removed.
 *
 * Citizens no longer register or log in. Because the District Admin holds the
 * authoritative beneficiary list (added via add_beneficiary.php or import.php),
 * the public viewer (view.php) is the only entry point residents need: pick
 * your district and barangay to see announcements, the distribution venue/
 * schedule, and the published final list. Anyone hitting this old URL is sent
 * straight there.
 */
require_once __DIR__ . '/includes/functions.php';
redirect('view.php');