# Deploying Ayuda to InfinityFree (free hosting, works on phones + laptops)

This puts the app online at a public address like
`https://yourname.infinityfreeapp.com/` that you can open from any phone or
laptop browser.

You need about 20 minutes. No credit card. I cannot create the account or type
in your details for you, so follow the steps below in order.

---

## 0. What is already prepared for you

- `config/db.php` now loads an optional `config/db.local.php` first. That means
  the **same code** works locally on XAMPP **and** on the live host, without
  editing `db.php` back and forth.
- `config/db.local.example.php` is a ready template for the live credentials.
- The `.htaccess` already blocks `sql/`, `_keep/`, `logs/`, dotfiles and
  `.sql/.log/.bak` files from being downloaded over the web. InfinityFree
  supports `.htaccess`, so your database dump and paperwork stay private.

---

## 1. Create the InfinityFree account

1. Go to <https://dash.infinityfree.com/register>.
2. Sign up with your email (a verification email is sent).
3. **Create a New Account / Website**.
   - Pick a free subdomain, e.g. `ayuda-cswdo` → `ayuda-cswdo.infinityfreeapp.com`
     (or `.rf.gd`, `.great-site.net`, etc.). This is the address you will open
     on your phone.
   - Choose "Create a new account" (not "Bring your own domain" unless you have one).
4. Wait ~1-5 minutes for it to activate (status goes **Active**).

---

## 2. Create the database

1. In the InfinityFree client area, open your account → **MySQL Databases**.
2. Create a database.
   - Database name: `ayuda_db` (the panel prefixes it, giving something like
     `if0_12345678_ayuda_db`).
   - Note the generated **database name**, **username** and the **password**
     you set. Also note the **host** shown, which looks like
     `sql302.infinityfree.com` (NOT `localhost`).
3. Open **phpMyAdmin** for that database (link on the same page).

## 3. Import the database

1. In phpMyAdmin, click your database in the left sidebar.
2. Go to the **Import** tab.
3. Click **Choose File** and pick `sql/ayuda_db_full.sql` from this project.
4. Leave the other options as-is and click **Import**.
   - The file is ~10 MB. InfinityFree's phpMyAdmin usually accepts this; if it
     reports the file is too large, use **Import → Choose from the web server**
     after uploading the .sql via the online File Manager into `htdocs/`, or
     split the dump. (See Troubleshooting below.)
5. When it finishes you should see the `ayuda_db` tables (beneficiaries, users,
   inventory, distribution_schedules, ...).

> Alternative to step 3 if phpMyAdmin chokes on 10 MB: upload
> `sql/ayuda_db_full.sql` with the File Manager, then in phpMyAdmin choose
> "Choose from the web server" and select it.

---

## 4. Put the live credentials in the deploy file

1. Open `deploy/db.local.php` (already created for you).
2. Replace the four `REPLACE_WITH_...` values with the ones from step 2, e.g.:

   ```php
   define('DB_HOST', 'sql302.infinityfree.com');
   define('DB_NAME', 'if0_12345678_ayuda_db');
   define('DB_USER', 'if0_12345678');
   define('DB_PASS', 'the-password-you-set');
   ```

   Also uncomment and set `BASE_URL` in that same file to your subdomain, e.g.
   `define('BASE_URL', 'https://ayuda-distribution.rf.gd/');`

   Do **not** edit `config/db.php` — leave it pointing at localhost. The packer
   (next step) drops this `deploy/db.local.php` into `config/db.local.php` inside
   the upload, so you never touch the live `config/` by hand.

---

## 5. Upload the files

> **Easiest path:** run the included packer, which copies only the files that
> belong online (skipping Windows-only scripts, `_keep/`, `logs/`, and local
> secrets) and produces `deploy/ayuda-upload.zip`:
>
> ```powershell
> powershell -NoProfile -ExecutionPolicy Bypass -File .\deploy\build-upload.ps1
> ```
>
> Then upload/extract that zip's **contents** into the host's `htdocs` folder.

Two options; pick one.

### Option A — Online File Manager (no software)

1. In the client area open **File Manager** for your account.
2. Open the `htdocs` folder.
3. Upload the project files. Easiest way: zip your project folder first
   (right-click → Send to → Compressed folder on Windows), upload the zip into
   `htdocs`, then use File Manager's **Extract**. If the zip contains a top-level
   `Ayuda/` folder, move its contents up so `index.php` sits directly inside
   `htdocs`.

### Option B — FTP (recommended for many files)

1. In the client area bar, click **FTP Details** and note: FTP host, username,
   password.
2. Install [FileZilla](https://filezilla-project.org/) (free).
3. Connect with those details, port 21.
4. Open the remote `htdocs` folder and upload everything **except**:
   - `_keep/` (capstone paperwork, old backups — not needed online)
   - `logs/` (local logs)
   - `start-ayuda.cmd`, `start-ayuda.ps1`, `install-ayuda.cmd` (Windows-only)
   - `config/db.local.php` IS needed (your live credentials)
   - Keep `sql/` only if you want; it is blocked from the web anyway.

> `htdocs` is the public web root. Whatever sits directly in it is served at
> your domain root, so `index.php` must be directly in `htdocs`.

---

## 6. Enable free SSL (https)

1. Client area → your account → **SSL Certificates** (or **Free SSL**).
2. Issue a certificate for your subdomain (self-service, takes a few minutes).
3. Once issued, your site is reachable at `https://yourname.infinityfreeapp.com/`.

(Optional but recommended: after HTTPS works, force it. Add to `.htaccess`:
`RewriteCond %{HTTPS} off` then `RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]`.)

---

## 7. First login and final checks

1. Open `https://yourname.infinityfreeapp.com/` on your phone.
2. Log in with the same accounts you use locally (the dump carried them over).
3. Because the live DB is the imported copy, **change the default/known
   passwords** before sharing the link.

---

## Troubleshooting

- **"Database Connection Error"** → `config/db.local.php` values are wrong.
  Double-check the MySQL **host** (`sql###.infinityfree.com`, not localhost),
  the prefixed database name, and the password.
- **Import says "file too large"** → use "Choose from the web server" after
  uploading the .sql to `htdocs` via File Manager, or split the dump.
- **Blank page / 500** → open via the client area's error log; usually a wrong
  path or a PHP version issue. Set PHP 8.1+ under **PHP Configuration**.
- **File Manager can't extract .rar** → re-zip the folder as **.zip**.
- **Changes to `db.php`?** Never needed; use `config/db.local.php`.

## Security notes (please read)

- The uploaded `sql/` still contains every real row and password hash in
  `ayuda_db_full.sql`. `.htaccess` blocks it, but for extra safety you can
  simply **not upload** `sql/` to the live host.
- Keep `config/db.local.php` out of any public repo.
- Rotate the Groq API key in `config/apis.local.php` if this project was ever
  shared publicly. The packer deliberately does **not** upload
  `config/apis.local.php`; on the live site sign in as Administrator and open
  **Menu → Integrations** to enter API keys again. Without keys the app still
  works, using its built-in offline assistant and keyless Leaflet map.
