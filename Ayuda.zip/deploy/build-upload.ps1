<#
  build-upload.ps1 - assemble a clean folder/zip of just the files that belong
  on the live host (InfinityFree). Run it, then upload the produced zip's
  contents into the host's "htdocs" folder.

  Usage:
    powershell -NoProfile -ExecutionPolicy Bypass -File .\deploy\build-upload.ps1
#>

$ErrorActionPreference = 'Stop'

$root    = Split-Path -Parent $PSScriptRoot          # ...\Ayuda
$stage   = Join-Path $PSScriptRoot 'upload'          # ...\Ayuda\deploy\upload
$zipPath = Join-Path $PSScriptRoot 'ayuda-upload.zip'

# Windows-only / local-only items that must NOT go to the web host.
$excludeNames = @(
    '_keep', 'logs', 'deploy',
    'start-ayuda.cmd', 'start-ayuda.ps1', 'install-ayuda.cmd',
    'db.local.php', 'apis.local.php'                 # secrets -> host sets its own
)
# Secret files that may live in ANY subfolder (matched by file name).
$excludeAnywhere = @('apis.local.php', 'db.local.php')
# Keep sql/ optional; it is blocked by .htaccess but you may not want it uploaded.
$includeSql = $true

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

Get-ChildItem -LiteralPath $root -Force | Where-Object {
    $n = $_.Name
    if ($excludeNames -contains $n) { return $false }
    if ($n -eq 'sql' -and -not $includeSql) { return $false }
    return $true
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $stage -Recurse -Force
}

# Remove any secret file that slipped in via a subfolder.
Get-ChildItem -LiteralPath $stage -Recurse -File -Force | Where-Object {
    $excludeAnywhere -contains $_.Name
} | Remove-Item -Force

# Provide the credential template (do not ship real secrets).
$example = Join-Path $root 'config\db.local.example.php'
if (Test-Path $example) {
    Copy-Item -LiteralPath $example -Destination (Join-Path $stage 'config\db.local.example.php') -Force
}

# If the user already filled in deploy\db.local.php, place it in config\ so the
# uploaded site is ready to connect. Otherwise fall back to the blank template.
$filled = Join-Path $PSScriptRoot 'db.local.php'
if (Test-Path $filled) {
    Copy-Item -LiteralPath $filled -Destination (Join-Path $stage 'config\db.local.php') -Force
    Write-Host "Included config/db.local.php from deploy\db.local.php (edit its values for the host!)."
}

# Force HTTPS on the live host (InfinityFree provides a free SSL cert).
$htFile = Join-Path $stage '.htaccess'
if (Test-Path $htFile) {
    $forceHttps = @'

# --- Force HTTPS on the live host (free SSL is auto-issued) ---------------
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteCond %{HTTP:X-Forwarded-Proto} !https
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
'@
    $enc = [Text.Encoding]::GetEncoding(28591)
    $ht = [IO.File]::ReadAllText($htFile, $enc)
    if ($ht -notmatch 'Force HTTPS') {
        [IO.File]::WriteAllText($htFile, ($ht.TrimEnd("`r","`n") + $forceHttps), $enc)
        Write-Host "Added HTTPS-force redirect to the staged .htaccess."
    }
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($stage, $zipPath)

$count = (Get-ChildItem -LiteralPath $stage -Recurse -File).Count
Write-Host "Staged $count files into $stage"
Write-Host "Upload archive: $zipPath"
Write-Host "Next: extract its CONTENTS directly into the host's htdocs folder."
