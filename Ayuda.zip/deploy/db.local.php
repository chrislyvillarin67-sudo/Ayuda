<?php
/**
 * LIVE credentials for InfinityFree (this file is loaded by config/db.php when
 * present, and is NEVER uploaded by deploy/build-upload.ps1 and never committed).
 *
 * >>> REPLACE the 4 values below with the ones shown in the InfinityFree panel:
 *     Client Area -> your account -> MySQL Databases. <<<
 *
 * Examples of what each should look like:
 *   DB_HOST = sql302.infinityfree.com      (the "MySQL Host" / "Hostname" row)
 *   DB_NAME = if0_12345678_ayuda_db        (the prefixed database name)
 *   DB_USER = if0_12345678                 (the MySQL username, = account id)
 *   DB_PASS = the password you set when creating the database
 */
define('DB_HOST', 'REPLACE_WITH_sql###.infinityfree.com');
define('DB_NAME', 'REPLACE_WITH_if0_########_ayuda_db');
define('DB_USER', 'REPLACE_WITH_if0_########');
define('DB_PASS', 'REPLACE_WITH_DB_PASSWORD');

/**
 * Public URL of the live site (used to build password-reset / welcome email
 * links). Set this to the free subdomain you chose at signup, e.g.
 *   define('BASE_URL', 'https://ayuda-distribution.rf.gd/');
 * Leave it commented to auto-detect from the request instead.
 */
// define('BASE_URL', 'https://REPLACE_WITH_SUBDOMAIN.rf.gd/');
