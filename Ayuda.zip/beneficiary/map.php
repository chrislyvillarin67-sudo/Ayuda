<?php
require_once __DIR__ . '/../includes/functions.php';
requireBeneficiary();

$stmt = $pdo->prepare("SELECT b.*, br.name AS barangay_name, d.name AS district_name
                        FROM beneficiaries b
                        JOIN barangays br ON br.id = b.barangay_id
                        JOIN districts d ON d.id = b.district_id
                        WHERE b.id = ?");
$stmt->execute([$_SESSION['beneficiary_id']]);
$beneficiary = $stmt->fetch();
if (!$beneficiary) { unset($_SESSION['beneficiary_id']); redirect('../login.php'); }

// DEVIATION (per doc feedback: "since wala pa gi approve dapat dili pa mog
// awas ang mga updates" / "Ayaw nalang butangi og map") -- while the
// beneficiary's registration is still pending, updates are not shown yet,
// and the map has been removed entirely (District Admin is the only role
// that gets a map now).
$isApproved = $beneficiary['status'] === 'approved';

$announcements = [];
if ($isApproved) {
    $annStmt = $pdo->prepare("
        SELECT a.*, br.name AS barangay_name, u.full_name AS created_by_name
        FROM announcements a
        LEFT JOIN barangays br ON br.id = a.barangay_id
        LEFT JOIN users u ON u.id = a.created_by
        WHERE a.barangay_id IS NULL OR a.barangay_id = ?
        ORDER BY (a.priority='high') DESC, a.created_at DESC, a.id DESC LIMIT 10
    ");
    $annStmt->execute([$beneficiary['barangay_id']]);
    $announcements = $annStmt->fetchAll();
}

// Mark updates as seen now that they've opened this page.
markBeneficiaryUpdatesSeen($pdo, $beneficiary['id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ayuda Updates - Ayuda Monitoring System</title>
<link rel="stylesheet" href="../assets/css/style.css?v=20261019b">
</head>
<body>
<div class="app-shell">
    <div class="app-header">
        <a href="dashboard.php" class="icon-btn"><?= svgIcon('left', 20) ?></a>
        <div style="text-align:center;">
            <h1>Ayuda Updates</h1>
            <div class="header-sub"><?= e($beneficiary['barangay_name']) ?>, <?= e($beneficiary['district_name']) ?></div>
        </div>
        <span style="width:20px;"></span>
        <a href="../logout.php" class="app-header-exit">Exit</a>
    </div>

    <div class="content">
        <?php if (!$isApproved): ?>
            <div class="card empty-state">
                <div class="es-icon"><?= svgIcon('clock', 26) ?></div>
                Updates will appear here once your registration is approved by your Barangay Staff.
            </div>
        <?php else: ?>
            <?php if ($announcements): ?>
            <div class="section-title">Announcements</div>
            <div class="ann-stack">
                <?php foreach ($announcements as $a): ?>
                    <article class="ann<?= $a['priority'] === 'high' ? ' ann-urgent' : '' ?>">
                        <div class="ann-head">
                            <div class="ann-ic"><?= svgIcon($a['priority'] === 'high' ? 'alert' : 'bell', 16) ?></div>
                            <div class="ann-main">
                                <div class="ann-title"><?= e($a['title']) ?></div>
                                <div class="ann-tags">
                                    <?php foreach (announcementChips($a) as [$chipText, $chipClass]): ?>
                                        <span class="badge <?= $chipClass ?>"><?= $chipText ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php $rows = announcementBody($a['message']); ?>
                        <?php if ($rows): ?>
                            <div class="ann-body">
                                <?php $first = true; foreach ($rows as $r): ?>
                                    <?php if ($r['label'] === null): ?>
                                        <p class="ann-note"<?= $first ? ' style="margin-top:0"' : '' ?>><?= nl2br($r['text']) ?></p>
                                    <?php else: ?>
                                        <div class="ann-row">
                                            <div class="ann-row-k"><?= e($r['label']) ?></div>
                                            <div class="ann-row-v"><?= nl2br($r['text']) ?></div>
                                        </div>
                                    <?php endif; ?>
                                    <?php $first = false; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="ann-foot"><?= announcementFoot($a) ?></div>
                    </article>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
                <div class="card empty-state">
                    <div class="es-icon"><?= svgIcon('bell', 26) ?></div>
                    <div class="es-title">No announcements yet</div>
                    <div class="es-sub">News from your barangay and the CSWDO will appear here.</div>
                </div>
            <?php endif; ?>

            <div class="alert alert-info mt-2">
                <?= svgIcon('info', 14) ?> Bring a valid ID and barangay clearance when claiming ayuda. For concerns, contact your Barangay Hall.
            </div>
        <?php endif; ?>

        <a href="../logout.php" class="btn btn-outline btn-block mt-3"><?= svgIcon('logout', 15) ?> Back to Exit</a>
    </div>
</div>
<?php include __DIR__ . '/../includes/chatbot_widget.php'; ?>
</body>
</html>
