<?php
require_once __DIR__ . '/../includes/functions.php';
requireBeneficiary();

$stmt = $pdo->prepare("
    SELECT b.*, br.name AS barangay_name, d.name AS district_name
    FROM beneficiaries b
    JOIN barangays br ON br.id = b.barangay_id
    JOIN districts d ON d.id = b.district_id
    WHERE b.id = ?
");
$stmt->execute([$_SESSION['beneficiary_id']]);
$beneficiary = $stmt->fetch();

if (!$beneficiary) {
    // Record no longer exists; clear stale session
    unset($_SESSION['beneficiary_id']);
    redirect('../login.php');
}

// A resident may belong to several categories; show them all.
$benCategories = beneficiaryCategories($pdo, (int)$beneficiary['id']);

$status = $beneficiary['status'] ?: 'pending';
$vstep = $beneficiary['verification_step'] ?? null;

$histStmt = $pdo->prepare("
    SELECT dl.distributed_at, dl.quantity, dl.amount, dl.assistance_type, i.item_name
    FROM distribution_logs dl JOIN inventory i ON i.id = dl.inventory_id
    WHERE dl.beneficiary_id = ? ORDER BY dl.distributed_at DESC
");
$histStmt->execute([$beneficiary['id']]);
$history = $histStmt->fetchAll();

// DEVIATION (per doc feedback: notification pop-up / red dot when there's an
// update, e.g. a newly approved status or new ayuda received).
$hasUnseenUpdates = beneficiaryHasUnseenUpdates($pdo, $beneficiary);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Dashboard - Ayuda Monitoring System</title>
<link rel="stylesheet" href="../assets/css/style.css?v=20261019b">
</head>
<body>
<div class="app-shell">
    <div class="app-header">
        <a href="map.php" class="icon-btn" title="Updates" aria-label="Updates">
            <?= svgIcon('bell', 20) ?><?php if ($hasUnseenUpdates): ?><span class="notif-dot"></span><?php endif; ?>
        </a>
        <div style="text-align:center;">
            <h1>My Ayuda Dashboard</h1>
            <div class="header-sub"><?= e($beneficiary['barangay_name']) ?>, <?= e($beneficiary['district_name']) ?></div>
        </div>
        <a href="../logout.php" class="app-header-exit">Exit</a>
    </div>

    <div class="content">
        <?php include __DIR__ . '/../includes/flash.php'; ?>

        <div class="card text-center" style="background:linear-gradient(135deg, var(--navy), var(--navy-light));color:#fff;">
            <div class="small" style="opacity:0.85;">Your Registered Gmail</div>
            <div style="font-size:24px;font-weight:800;letter-spacing:0.5px;margin:4px 0;word-break:break-all;"><?= e($beneficiary['beneficiary_code']) ?></div>
            <div class="small" style="opacity:0.85;">Use this Gmail address (with your password) to log back in anytime.</div>
        </div>

        <div class="card text-center">
            <div class="small text-muted">Application Status</div>
            <div style="margin:10px 0;">
                <span class="badge <?= statusBadgeClass($status) ?>" style="font-size:14px;padding:8px 18px;">
                    <?= ucfirst(e(statusLabel($status))) ?>
                </span>
            </div>
            <?php if ($status === 'pending' && $vstep !== 'cswdo'): ?>
                <p class="small text-muted mb-0">Your application is undergoing barangay verification. Please check back soon.</p>
            <?php elseif ($status === 'pending' && $vstep === 'cswdo'): ?>
                <p class="small text-muted mb-0">Initial barangay verification complete. Your application is now awaiting CSWDO final validation.</p>
            <?php elseif ($status === 'rejected'): ?>
                <p class="small text-muted mb-0" style="color:var(--danger);">Your application was rejected. Reason: <?= e($beneficiary['rejected_reason'] ?: 'Not stated. Please contact your barangay staff.') ?></p>
            <?php elseif ($status === 'returned'): ?>
                <p class="small text-muted mb-0" style="color:var(--navy);">Your application needs correction: <?= e($beneficiary['return_reason'] ?: 'Please contact your barangay staff to update your information.') ?></p>
            <?php else: ?>
                <p class="small text-muted mb-0">You are eligible to receive ayuda distributions in your barangay.</p>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="li-sub" style="margin-bottom:8px;">Your Application Timeline</div>
            <?php
            // Timeline reflects the real workflow stage via status + verification_step
            $rejected = $status === 'rejected';
            $returned = $status === 'returned';
            $barangayDone = $rejected || in_array($vstep, ['cswdo','approved'], true);
            $cswdoDone   = $rejected || $vstep === 'approved';
            $approved    = $rejected || $status === 'approved';
            $steps = [
                ['Submitted', true],
                ['Under Barangay Verification', $barangayDone],
                ['For CSWDO Validation', $cswdoDone],
                ['Approved', $approved],
                ['Scheduled for Distribution', $approved && $history],
                ['Distributed', (bool)$history],
            ];
            ?>
            <?php foreach ($steps as $i => $step):
                $complete = $step[1]; ?>
                <div class="list-item" style="<?= $complete ? '' : 'opacity:0.5;' ?>">
                    <div class="li-name"><?= $complete ? svgIcon('check', 15) . ' ' : '&#9679; ' ?><?= e($step[0]) ?></div>
                </div>
            <?php endforeach; ?>
            <?php if ($status === 'rejected'): ?>
                <div class="alert alert-danger mb-0 mt-2">Your application was rejected. Please contact your barangay office for assistance.</div>
            <?php elseif ($status === 'returned'): ?>
                <div class="alert alert-warning mb-0 mt-2">Please update the required information and resubmit. Contact your barangay staff for details.</div>
            <?php endif; ?>
        </div>

        <div class="section-title">My Information</div>
        <div class="card">
            <div class="list-item"><div><div class="li-sub">Full Name</div><div class="li-name"><?= e($beneficiary['full_name']) ?></div></div></div>
            <div class="list-item"><div><div class="li-sub">Address</div><div class="li-name"><?= e($beneficiary['address']) ?></div></div></div>
            <div class="list-item"><div><div class="li-sub">Category</div><div class="li-name"><?= e(implode(', ', $benCategories ?: [(string)$beneficiary['category']])) ?></div></div></div>
            <?php if ($beneficiary['contact_number']): ?>
            <div class="list-item"><div><div class="li-sub">Contact Number</div><div class="li-name"><?= e($beneficiary['contact_number']) ?></div></div></div>
            <?php endif; ?>
        </div>

        <div class="section-title">Ayuda History</div>
        <div class="card">
            <?php if ($status !== 'approved'): ?>
                <div class="empty-state"><div class="es-icon"><?= svgIcon('box', 26) ?></div>History will appear once your registration is approved.</div>
            <?php elseif (!$history): ?>
                <div class="empty-state"><div class="es-icon"><?= svgIcon('box', 26) ?></div>No ayuda received yet.</div>
            <?php else: ?>
                <?php foreach ($history as $h): ?>
                    <div class="list-item">
                        <div>
                            <div class="li-name"><?= e($h['item_name']) ?><?= $h['assistance_type'] === 'cash' && (float)$h['amount'] > 0 ? ' &mdash; &#8369;' . number_format((float)$h['amount'], 2) : ' &times; ' . (int)$h['quantity'] ?></div>
                            <div class="li-sub">Received</div>
                        </div>
                        <span class="small text-muted"><?= timeAgo($h['distributed_at']) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="alert alert-info">
            <?= svgIcon('info', 14) ?> Important: Bring a valid ID and your barangay clearance when claiming ayuda.
        </div>

        <?php if ($status === 'approved'): ?>
            <a href="map.php" class="btn btn-primary btn-block mt-2"><?= svgIcon('bell', 15) ?> View Ayuda Updates<?php if ($hasUnseenUpdates): ?> <span class="notif-dot" style="position:static;display:inline-block;margin-left:6px;"></span><?php endif; ?></a>
        <?php else: ?>
            <div class="small text-muted text-center mt-2">Updates will be available once your registration is approved.</div>
        <?php endif; ?>

        <a href="../logout.php" class="btn btn-outline btn-block mt-2"><?= svgIcon('logout', 15) ?> Back to Exit</a>
    </div>
</div>
<?php include __DIR__ . '/../includes/chatbot_widget.php'; ?>
</body>
</html>
