<?php
?>
<div class="final-list-item" id="ben-<?= (int)$m['id'] ?>">
    <div>
        <div class="li-name">
            <a href="beneficiary_detail.php?id=<?= (int)$m['id'] ?>" style="color:inherit;text-decoration:none;border-bottom:1px dotted #9aa7b5;">
                <?= e(formatName($m['full_name'])) ?>
            </a>
            <?php if ($m['is_duplicate']): ?><span title="Possible duplicate"><?= svgIcon('alert', 16) ?></span><?php endif; ?>
        </div>
        <div class="li-sub">
            <?php
            $rowCats = $m['categories'] ?? [(string)($m['category'] ?? '')];
            $rowCats = array_values(array_filter($rowCats, fn($c) => $c !== ''));
            ?>
            <?php foreach ($rowCats as $rc): ?><span class="badge badge-navy" style="font-size:10.5px;"><?= e($rc) ?></span> <?php endforeach; ?>
            <span style="opacity:.7;"><?= e($m['barangay_name']) ?></span>
        </div>
    </div>
    <div class="d-flex align-center gap-2">
        <a href="beneficiary_detail.php?id=<?= (int)$m['id'] ?>" class="btn btn-outline btn-sm">View</a>
    </div>
</div>