<?php
/**
 * Live hosting credentials (TEMPLATE).
 *
 * Copy this file to config/db.local.php and fill in the values from your
 * hosting control panel (InfinityFree -> MySQL Databases). config/db.php loads
 * db.local.php automatically when it exists, so you never edit db.php itself.
 *
 * On InfinityFree the MySQL host is NOT "localhost" -- it looks like
 * sql###.infinityfree.com (e.g. sql302.infinityfree.com), and the database
 * name and username are both prefixed with your account id, e.g.
 *   host     = sql302.infinityfree.com
 *   name     = if0_12345678_ayuda_db
 *   user     = if0_12345678
 *   password = the password you set when creating the database
 */

define('DB_HOST', 'sql109.infinityfree.com');
define('DB_NAME', 'if0_43223810_ayuda_db');
define('DB_USER', 'if0_43223810');
define('DB_PASS', 'washewep');

// Optional: force the public base URL used in emails (reset links, etc).
// Leave commented to auto-detect. Uncomment and set to your live address.
// define('BASE_URL', 'https://yourname.infinityfreeapp.com/');
